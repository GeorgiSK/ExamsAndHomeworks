package problem_02;

public interface Birthable {
    String getId();
}
