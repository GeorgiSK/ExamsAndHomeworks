package problem_02;

public interface Identifiable {
    String getBirthdate();
}
